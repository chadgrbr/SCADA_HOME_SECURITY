ssh openplc@192.168.8.2 /home/openplc/Mitigations/PacketFilterOff.sh
