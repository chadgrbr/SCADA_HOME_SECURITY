sudo iptables -F INPUT
