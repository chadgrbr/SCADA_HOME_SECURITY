# Flush Arp Cache
sudo ip link set arp off dev eth0 ; sudo ip link set arp on dev eth0
