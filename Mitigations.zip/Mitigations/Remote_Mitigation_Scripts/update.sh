rsync -aAXo ~/Mitigations/Remote_Mitigation_Scripts/scadabr/* scadabr@192.168.8.1:Mitigations/
rsync -aAXo ~/Mitigations/Remote_Mitigation_Scripts/openplc/* openplc@192.168.8.2:Mitigations/
