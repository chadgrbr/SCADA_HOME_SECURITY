ssh openplc@192.168.8.2 /home/openplc/Mitigations/RemoveStaticArpEntry.sh
ssh scadabr@192.168.8.1 /home/scadabr/Mitigations/RemoveStaticArpEntry.sh
